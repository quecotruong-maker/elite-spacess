HOTELFLOW - CUSTOMER REPORTS PAYMENT

Workflow:
1. Customer transfers money through bank QR.
2. Customer opens invoice and clicks "TÔI ĐÃ THANH TOÁN".
3. Admin invoice list displays "Khách báo đã thanh toán · Chờ xác nhận".
4. Admin checks actual incoming transfer and clicks "Xác nhận đã thu".
5. System records the confirmed payment in the existing thanh_toan table and changes claim status to confirmed.
6. Admin Notifications shows a payment-report alert linking to invoices.

The claim table is created automatically when customer invoice/Admin invoice pages are opened. SQL migration is also included at sql/update_customer_payment_report.sql.
IMPORTANT: Admin should verify bank receipt before clicking confirm. The customer report button does NOT itself mark money received.
