<?php
require __DIR__.'/_common.php';
requireCustomer();
$id=(int)($_GET['id']??0);$status='Chờ xác nhận';$booking=null;$depositStatus='Chưa báo thanh toán cọc';$depositAmount=0;$total=0;$bank=[];
if(empty($_SESSION['deposit_csrf']))$_SESSION['deposit_csrf']=bin2hex(random_bytes(32));
try{
 if($pdo){
  $pdo->exec("CREATE TABLE IF NOT EXISTS booking_deposit_claims (id INT AUTO_INCREMENT PRIMARY KEY, booking_id INT NOT NULL UNIQUE, customer_id INT NOT NULL, deposit_amount DECIMAL(18,0) NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'reported', reported_at DATETIME NULL, confirmed_at DATETIME NULL, admin_id VARCHAR(255) NULL, INDEX(booking_id)) ENGINE=InnoDB");
  $q=$pdo->prepare("SELECT d.ma_dat_phong,d.trang_thai,d.ngay_den,d.ngay_di,p.so_phong,lp.ten_loai,lp.gia_mot_dem,k.ma_khach,k.ho_ten FROM dat_phong d JOIN phong p ON p.ma_phong=d.ma_phong JOIN loai_phong lp ON lp.ma_loai_phong=p.ma_loai_phong JOIN khach_hang k ON k.ma_khach=d.ma_khach WHERE d.ma_dat_phong=? AND d.ma_khach=?");
  $q->execute([$id,customerUser()['customer_id']??0]);$booking=$q->fetch();
  if($booking){$status=$booking['trang_thai'];$nights=max(1,(int)((strtotime($booking['ngay_di'])-strtotime($booking['ngay_den']))/86400));$total=$nights*(float)$booking['gia_mot_dem'];}
 }
}catch(Throwable $e){}

if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['report_deposit'])&&$booking&&$pdo){
 if(!hash_equals($_SESSION['deposit_csrf'],(string)($_POST['csrf']??'')))$depositStatus='Phiên thao tác không hợp lệ. Tải lại trang.';
 else try{$depositAmount=round($total*0.2);$q=$pdo->prepare("SELECT status FROM booking_deposit_claims WHERE booking_id=?");$q->execute([$id]);$old=$q->fetchColumn();
 if($old==='confirmed')$depositStatus='Đã được Admin xác nhận cọc';
 elseif($old==='reported')$depositStatus='Bạn đã báo thanh toán cọc, đang chờ Admin xác nhận';
 else{$q=$pdo->prepare("INSERT INTO booking_deposit_claims(booking_id,customer_id,deposit_amount,status,reported_at) VALUES(?,?,?,'reported',NOW()) ON DUPLICATE KEY UPDATE status='reported',deposit_amount=VALUES(deposit_amount),reported_at=NOW(),confirmed_at=NULL");$q->execute([$id,customerUser()['customer_id'],$depositAmount]);$depositStatus='Đã báo thanh toán cọc, chờ Admin xác nhận';}
 }catch(Throwable $e){$depositStatus='Không gửi được báo thanh toán cọc. Vui lòng thử lại.';}
}
if($booking&&$pdo){try{$q=$pdo->prepare('SELECT status,deposit_amount FROM booking_deposit_claims WHERE booking_id=?');$q->execute([$id]);$c=$q->fetch();if($c){$depositStatus=$c['status']==='confirmed'?'Đã thanh toán cọc 20% · Admin xác nhận':($c['status']==='reported'?'Khách đã báo thanh toán cọc · Chờ Admin xác nhận':'Chưa báo thanh toán cọc');$depositAmount=(float)$c['deposit_amount'];}else $depositAmount=round($total*0.2);$bank=$pdo->query('SELECT * FROM cai_dat_ngan_hang WHERE id=1')->fetch()?:[];}catch(Throwable $e){}}
customerHeader('Gửi yêu cầu đặt phòng thành công');
?>
<main class="container"><div class="bookingpanel" style="max-width:760px;margin:42px auto;padding:30px">
<div style="text-align:center"><div style="font-size:48px;color:#20a36a">✓</div><div class="section-kicker">GLOBAL HOTEL · ĐẶT PHÒNG</div><h1>Đã gửi yêu cầu đặt phòng</h1><p>Yêu cầu của bạn đã được ghi nhận. Để giữ phòng, vui lòng thanh toán cọc 20% tổng tiền.</div>
<?php if($booking):?><p style="font-size:18px;text-align:center"><strong>Mã đặt phòng: #<?=h($id)?></strong></p>
<div style="background:#f4f7fc;border-radius:12px;padding:16px"><p><b>Phòng:</b> <?=h($booking['so_phong'])?> · <?=h($booking['ten_loai'])?></p><p><b>Tổng tiền dự kiến:</b> <?=number_format($total,0,',','.')?> ₫</p><p><b>Tiền cọc bắt buộc (20%):</b> <strong style="color:#136c42"><?=number_format($depositAmount,0,',','.')?> ₫</strong></p><p><b>Trạng thái cọc:</b> <?=h($depositStatus)?></p></div>
<?php $qr='';if(!empty($bank['trang_thai'])&&!empty($bank['ma_ngan_hang'])&&!empty($bank['so_tai_khoan']))$qr='https://img.vietqr.io/image/'.rawurlencode($bank['ma_ngan_hang']).'-'.rawurlencode($bank['so_tai_khoan']).'-compact2.png?amount='.rawurlencode((string)round($depositAmount)).'&addInfo='.rawurlencode('Coc booking '.$id).'&accountName='.rawurlencode($bank['ten_chu_tai_khoan']??'');
if($qr):?><div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap;background:#f8faff;border:1px solid #dbe7f7;border-radius:14px;padding:18px;margin-top:16px"><div style="flex:1;min-width:220px"><h3>Thanh toán cọc bằng QR</h3><p><b>Ngân hàng:</b> <?=h($bank['ten_ngan_hang']??'')?></p><p><b>Chủ tài khoản:</b> <?=h($bank['ten_chu_tai_khoan']??'')?></p><p><b>Số tài khoản:</b> <?=h($bank['so_tai_khoan'])?></p><p><b>Số tiền cọc:</b> <?=number_format($depositAmount,0,',','.')?> ₫</p><p><b>Nội dung:</b> Coc booking <?=$id?></p></div><div><img src="<?=h($qr)?>" alt="QR cọc 20%" style="width:210px;max-width:100%;border:1px solid #ddd;background:white;padding:5px;border-radius:8px"></div></div><?php endif;?>
<?php if($depositStatus==='Chưa báo thanh toán cọc'): ?><form method="post" style="margin-top:18px;text-align:center"><input type="hidden" name="csrf" value="<?=h($_SESSION['deposit_csrf'])?>"><button class="btn" name="report_deposit" value="1" style="background:#16a34a;padding:14px 24px;font-weight:bold">✓ TÔI ĐÃ THANH TOÁN CỌC 20%</button><p class="muted">Sau khi chuyển tiền, bấm nút để thông báo Admin. Admin sẽ kiểm tra giao dịch thực tế.</p></form><?php elseif($depositStatus==='Khách đã báo thanh toán cọc · Chờ Admin xác nhận'):?><div style="margin-top:16px;text-align:center;background:#fff7e6;color:#925900;padding:12px;border-radius:10px;font-weight:bold">⏳ Đã gửi thông báo cho Admin. Đang chờ xác nhận tiền cọc.</div><?php endif;?>
<?php endif;?>
<div style="display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin-top:20px"><a class="btn" href="my-bookings.php">Đặt phòng của tôi</a><a class="btn outline" href="rooms.php">Tiếp tục xem phòng</a></div></div></main><?php customerFooter();?>
