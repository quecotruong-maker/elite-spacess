<?php
require __DIR__.'/_common.php';
requireCustomer();
$id=(int)($_GET['id']??0);$u=customerUser();
if(!$id){header('Location: my-bookings.php');exit;}
$q=$pdo->prepare('SELECT ma_dat_phong,trang_thai FROM dat_phong WHERE ma_dat_phong=? AND ma_khach=?');$q->execute([$id,$u['customer_id']]);$booking=$q->fetch();
if(!$booking){http_response_code(403);customerHeader('Không có quyền truy cập');echo '<main class="container"><div class="bookingpanel">Bạn không có quyền xem đơn đặt phòng này. <a href="my-bookings.php">Quay lại</a></div></main>';customerFooter();exit;}
header('Location: invoice.php?id='.$id);exit;
