-- HOTELFLOW mandatory 20% deposit workflow
CREATE TABLE IF NOT EXISTS booking_deposit_claims (
 id INT AUTO_INCREMENT PRIMARY KEY,
 booking_id INT NOT NULL UNIQUE,
 customer_id INT NOT NULL,
 deposit_amount DECIMAL(18,0) NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'reported',
 reported_at DATETIME NULL,
 confirmed_at DATETIME NULL,
 admin_id VARCHAR(255) NULL,
 INDEX(booking_id)
) ENGINE=InnoDB;
