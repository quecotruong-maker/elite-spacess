-- HOTELFLOW: Customer payment report -> Admin verification
CREATE TABLE IF NOT EXISTS invoice_payment_claims (
  id INT AUTO_INCREMENT PRIMARY KEY,
  invoice_id INT NOT NULL UNIQUE,
  booking_id INT NOT NULL,
  customer_id INT NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'reported',
  reported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  confirmed_at DATETIME NULL,
  admin_id VARCHAR(255) NULL,
  INDEX (booking_id)
) ENGINE=InnoDB;
